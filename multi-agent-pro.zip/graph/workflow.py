from langgraph.graph import StateGraph
from typing import TypedDict

from agents.pm import pm_agent
from agents.architect import architect_agent
from agents.dev import dev_agent
from agents.qa import qa_agent
from agents.reviewer import reviewer_agent

class AgentState(TypedDict):
    requirement: str
    tasks: str
    architecture: str
    code: str
    qa: str
    final: str

def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("pm", pm_agent)
    graph.add_node("architect", architect_agent)
    graph.add_node("dev", dev_agent)
    graph.add_node("qa", qa_agent)
    graph.add_node("reviewer", reviewer_agent)

    graph.set_entry_point("pm")
    graph.add_edge("pm", "architect")
    graph.add_edge("architect", "dev")
    graph.add_edge("dev", "qa")
    graph.add_edge("qa", "reviewer")

    graph.set_finish_point("reviewer")

    return graph.compile()
