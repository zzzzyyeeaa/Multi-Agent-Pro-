def run_python(code: str):
    try:
        exec_globals = {}
        exec(code, exec_globals)
        return "success"
    except Exception as e:
        return str(e)
