from graph.workflow import build_graph

if __name__ == "__main__":
    app = build_graph()
    result = app.invoke({"requirement": "开发一个任务管理系统"})
    print(result["final"])
