from utils.llm import call_llm

def dev_agent(state):
    result = call_llm("你是开发工程师", f"写代码: {state['architecture']}")
    return {"code": result}
