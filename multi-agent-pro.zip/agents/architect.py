from utils.llm import call_llm

def architect_agent(state):
    result = call_llm("你是架构师", f"设计架构: {state['tasks']}")
    return {"architecture": result}
