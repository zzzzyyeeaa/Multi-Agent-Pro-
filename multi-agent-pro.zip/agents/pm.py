from utils.llm import call_llm

def pm_agent(state):
    result = call_llm("你是产品经理", f"拆解需求: {state['requirement']}")
    return {"tasks": result}
