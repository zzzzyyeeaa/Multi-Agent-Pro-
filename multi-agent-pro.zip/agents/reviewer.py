from utils.llm import call_llm

def reviewer_agent(state):
    result = call_llm("你是代码评审", f"优化代码: {state['code']} \n QA: {state['qa']}")
    return {"final": result}
