from utils.llm import call_llm

def qa_agent(state):
    result = call_llm("你是测试工程师", f"测试代码: {state['code']}")
    return {"qa": result}
