from openai import OpenAI
from config.settings import OPENAI_API_KEY, MODEL_NAME

client = OpenAI(api_key=OPENAI_API_KEY)

def call_llm(system, user):
    response = client.chat.completions.create(
        model=MODEL_NAME,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user}
        ],
        temperature=0.7
    )
    tokens = response.usage.total_tokens if response.usage else 0
    print(f"Tokens used: {tokens}")
    return response.choices[0].message.content
